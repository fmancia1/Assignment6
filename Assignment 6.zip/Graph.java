import java.util.ArrayList;
import java.util.Set;
import java.lang.NullPointerException;

public class Graph<V,E> implements GraphInterface<V, E> {
  ArrayList<E> edgeList;
  int[] dist;
  public E getEdge(V sourceVertex, V destinationVertex) {
    E selection = null;
    for (E edge : edgeList) {
      if (edge.getSource().equals(sourceVertex) && edge.getDestination().equals(destinationVertex)) {
        selection = edge;
        break;
      }
    }
    return selection;
  } 
  public E addEdge(V sourceVertex, V destinationVertex, int weight, String description) {
    /*
    if (edge == null) {
      throw NullPointerException("Null Pointer");
    }
    */
    E edge = new E(sourceVertex, destinationVertex, weight, description);
    edgeList.add(edge);
    return edge;
  }
  public boolean addVertex(V v) {
    if (v == null) {
      throw NullPointerException("Null Pointer");
    }
    boolean flag = false;
    for (E edge : edgeList) {
      if (edge.equals(v)) {
        flag = true;
        break;
      }
    }
    if (!flag) {
      edgeList.add(v);
    }
    return flag;
  }
  public boolean containsEdge(V sourceVertex, V destinationVertex) {
    boolean flag = false;
    for (E edge : edgeList) {
      if (edge.getSource().equals(sourceVertex) && edge.getDestination().equals(destinationVertex)) {
        flag = true;
        break;
      }
      else {
        flag = false;
        break;
      }
    }
    return flag;
  }
  public boolean containsVertex(V v) {
    boolean flag = false;
      for (E edge : edgeList) {
        if (edge.equals(v)) {
          flag = true;
          break;
        }
      }
      return flag;
  }
 public Set<E> edgeSet() {
   Set<E> set = new Set<E>();
   for (E edge : edgeList) {
     if (!set.contains(edge)) {
       set.add(edge);
     }
   }
   return set;
 }
 public Set<V> vertexSet() {
   Set<V> set = new Set<V>();
   for (E edge : edgeList) {
      if (! set.contains(edge.getSource()))
        set.add(edge.getSource());
      if (! set.contains(edge.getDestination()))
        set.add(edge.getDestination());
   }
   return set;
 } 
 public Set<E> edgesOf(V vertex) {
   Set<E> set = new Set<E>();
   for (E edge : edgeList){
   if (edge.getDestination().equals(vertex)) {
     set.add(edge);
    }
   }
   return set;
 }
 public E removeEdge(V sourceVertex, V destinationVertex, int weight, String description) {
   E edge = new E(sourceVertex, destinationVertex, weigth, name);
   for (E link : edgeList) {
     if (link.equals(edge)) {
       edgeList.remove(link);
     }
   }
    return edge;
 }
 public boolean removeVertex(V v) {
   boolean flag = false;
   for (E edge : edgeList) {
     if (edge.getSource().equals(v) || edge.getDestination().equals(v)) {
       edgeList.remove(edge);
       flag = true;
     }
   }
   return flag;
 }
 public ArrayList<String> shortestPath(V sourceVertex, V destinationVertex) {
   int min = Integer.MAX_VALUE, min_index = -1;
   for (int sourceVertex = 0; sourceVertex < destinationVertex; v++) {
     if (sptSet[sourceVertex] == false && dist[destinationVertex] <= min) {
       min = dist[destinationVertex];
       min_index = destinationVertex;
     }
   }
 }
 public void dijkstraShortestPath(V sourceVertex) {
   int[][] mat = graphMatrix();
   Set<E> set = vertexSet();
   int n = set.size();
   int source = set.toArray().indexOf(sourceVertex);
   dist = new int[n];
   boolean[] sptSet = new boolean[n];
   for (int i = 0; i < dist.length; i++) {
     dist[i] = Integer.MAX_VALUE;
     sptSet[i] = false;
   }
   dist[source] = 0;
   for (int count = 0; count < n - 1; count++) {
     int u = minDistance(dist, sptSet);
     sptSet[u] = true;
     for (int v = 0; v < n; v++) {
       if (!sptSet[v] && mat[u][v] != 0 && dist[u] != Integer.MAX_VALUE && dist[u] + mat[u][v] < dist[v])
          dist[v] = dist[u] + mat[u][v];
     }
   }
 }
 private int[][] graphMatrix() {
   Set<E> set = vertexSet();
   int n = set.size();
   int[][] mat = new int[n][n];
   for (E edge : edgeList) {
     int s = set.indexOf(edge.getSource());
     int d = set.indexOf(edge.getDestination());
     mat[s][d] = edge.getWeight();
   }
   return mat;
 }
 private int minDistance(int[] dist, boolean[] sptSet) {
   int min = Integer.MAX_VALUE;
   int min_index = -1;
   for (int i = 0; i < dist.length; i++) {
     if (sptSet[i] == false && dist[i] <= min) {
       min = dist[i];
       min_index = i;
     }
   }
   return min_index;
 }
}