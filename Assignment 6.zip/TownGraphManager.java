public class TownGraphManager implements TownGraphManagerInterface {
  ArrayList<Town> adjacents;
  public boolean addRoad(String town1, String town2, int weight, String roadName) {

  }
  public String getRoad(String town1, String town2) {
    return town1 + town2 + weight + roadName;
  }
  public boolean addTown(String v) {

  }
  public Town getTown(String name) {
    return name;
  }
  public boolean containsTown(String v) {
     boolean flag = false;
      for (E adjacents : adjacents) {
        if (adjacent.name.equals(v)) {
          flag = true;
          break;
        }
      }
      return flag;
  }
  public boolean containsRoadConnection(String town1, String town2) {
    boolean flag = false;
    for (E edge : adjacents) {
      if (edge.getSource().equals(town1) && edge.getDestination().equals(town2)) {
        flag = true;
        break;
      }
      else {
        flag = false;
        break;
      }
    }
    return flag;
  }
}