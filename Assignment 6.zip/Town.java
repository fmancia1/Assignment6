import java.util.ArrayList;

public class Town implements Comparable<Town> {
  String name;
  ArrayList<Town> adjacents;
  // Town templateTown;
  Town(String name) {
    this.name = name;
    adjacents = new ArrayList<Towm>();
  }
  Town(Town templateTown) {
    name = templateTown.name;
    adjacents = templateTown.adjacents;
  }
  public String getName() {
    return name;
  }
  public int compareTo(Town o) {
    return name.compareTo(o.name);
  }
  public String toString() {
    return name;
  }
  public int hashCode() {
    return name.hashCode();
  }
  public boolean equals(Town o) {
    return name.equals(o.name);
  }
}