public class Road implements Comparable<Road> {
  Town source;
  Town destination;
  int degrees;
  String name;
  public Road(Town source, Town destination, int degrees, String name) {
    this.name = name;
    this.source = source;
    this.destination = destination;
    this.degrees = degrees;
  }
  public Road(Town source, Town destination,String name) {
    this.name = name;
    this.source = source;
    this.destination = destination;
    this.degrees = 1;
  }
  public boolean contains(Town town) {
    return town.equals(source) || town.equals(destination);
  }
  public String toString() {
    return name + ": " + source.getName() + '-' + destination.getName();
  }
  public String getName() {
    return name;
  }
  public Town getDestination() {
    return destination;
  }
  public Town getSource() {
    return source;
  }
  public int compareTo(Road o) {
    return name.compareTo(o.name);
  }
  public int getWeight() {
    return degrees;
  }
  public boolean equals(Object r) {
    return name.equals(r.name) && source.equals(r.getSource()) && destination.equals(r.getDestination()) && degrees == r.getWeight();
  }
}