import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class Road_STUDENT_Test {
  private Road<Town,Road> graph;
  private String[] town;

  @Test
  public boolean testContains(Town town) {
    assertEquals(true, graph.contains(town[2]));
    assertEquals(false, graph.contains(town[3]));
  }
  @Test
  public String testtoString() {
    
  }
}