/**
* This is the Town class
*
*
* @author Fatima Mancia
*
*/
import java.util.ArrayList;

public class Town implements Comparable<Town> {
  String name;
  ArrayList<Town> adjacents;
  // Town templateTown;
  Town(String name) {
    this.name = name;
    adjacents = new ArrayList<Town>();
  }
  Town(Town templateTown) {
    name = templateTown.name;
    adjacents = templateTown.adjacents;
  }
  public String getName() {
    return name;
  }
   /**
	 * compareTo compares the town name.
     @param o.
	 * @return int.
	 *
	 */
  public int compareTo(Town o) {
    return name.compareTo(o.name);
  }
  /**
	 * toString gets the Name of the town.
	 * @return the name of the town.
	 *
	 */
  public String toString() {
    return name;
  }
  /**
	 * toString gets the Name of the source.
	 * @return the hashCode.
	 *
	 */
  public int hashCode() {
    return name.hashCode();
  }
   /**
	 * equals compares the two names.
     @param o.
	 * @return true if the town equals the name.
	 *
	 */
  public boolean equals(Town o) {
    return name.equals(o.name);
  }
}