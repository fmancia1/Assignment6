import java.util.ArrayList;
import java.util.HashSet;
import java.lang.NullPointerException;

public class Graph implements GraphInterface<Town, Road> {
  
  ArrayList<Road> edgeList;
  ArrayList<Town> vertexList; 
  int[] dist;

  public Graph() {
    edgeList = new ArrayList<Road>();
    vertexList = new ArrayList<Town>();
  }

  public Road getEdge(Town sourceVertex, Town destinationVertex) {
    Road selection = null;
    for (Road edge : edgeList) {
      if (edge.getSource().equals(sourceVertex) && edge.getDestination().equals(destinationVertex)) {
        selection = edge;
        break;
      }
    }
    return selection;
  }
  
  public Road addEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
    /*
    if (edge == null) {
      throw NullPointerException("Null Pointer");
    }
    */
    addVertex(sourceVertex);
    addVertex(destinationVertex);
    Road edge = new Road(sourceVertex, destinationVertex, weight, description);
    edgeList.add(edge);
    return edge;
  }
  public boolean addVertex(Town v) {
    if (v == null) {
      throw new NullPointerException();
    }
    boolean flag = false;
    for (Road edge : edgeList) {
      if (edge.equals(v)) {
        flag = true;
        break;
      }
    }
    if (!flag) {
      vertexList.add(v);
    }
    return flag;
  }

  public boolean containsEdge(Town sourceVertex, Town destinationVertex) {
    boolean flag = false;
    for (Road edge : edgeList) {
      if (edge.getSource().equals(sourceVertex) && edge.getDestination().equals(destinationVertex)) {
        flag = true;
        break;
      }
      else {
        flag = false;
        break;
      }
    }
    return flag;
  }

  public boolean containsVertex(Town v) {
    boolean flag = false;
      for (Town vertex : vertexList) {
        if (vertex.equals(v)) {
          flag = true;
          break;
        }
      }
      return flag;
  }
 
 public HashSet<Road> edgeSet() {
   HashSet<Road> set = new HashSet<Road>();
   for (Road edge : edgeList) {
     if (!set.contains(edge)) {
       set.add(edge);
     }
   }
   return set;
 }
 
 public HashSet<Town> vertexSet() {
   HashSet<Town> set = new HashSet<Town>();
   for (Road edge : edgeList) {
      if (! set.contains(edge.getSource()))
        set.add(edge.getSource());
      if (! set.contains(edge.getDestination()))
        set.add(edge.getDestination());
   }
   return set;
 } 
 
 public HashSet<Road> edgesOf(Town vertex) {
   HashSet<Road> set = new HashSet<Road>();
   for (Road edge : edgeList){
   if (edge.getDestination().equals(vertex)) {
     set.add(edge);
    }
   }
   return set;
 }

 public Road removeEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
   Road edge = new Road(sourceVertex, destinationVertex, weight, description);
   for (Road link : edgeList) {
     if (link.equals(edge)) {
       edgeList.remove(link);
     }
   }
    return edge;
 }

 public boolean removeVertex(Town v) {
   boolean flag = false;
   for (Road edge : edgeList) {
     if (edge.getSource().equals(v) || edge.getDestination().equals(v)) {
       edgeList.remove(edge);
       flag = true;
     }
   }
   return flag;
 }

 public ArrayList<String> shortestPath(Town sourceVertex, Town destinationVertex) {
   /*
   int min = Integer.MAX_VALUE, min_index = -1;
   for (int sourceVertex = 0; sourceVertex < destinationVertex; v++) {
     if (sptSet[sourceVertex] == false && dist[destinationVertex] <= min) {
       min = dist[destinationVertex];
       min_index = destinationVertex;
     }
   }
   */
   return null;
 }

 public void dijkstraShortestPath(Town sourceVertex) {
   int[][] mat = graphMatrix();
   int n = vertexList.size();
   dist = new int[n];
   int pos = vertexList.indexOf(sourceVertex);
   boolean[] sptSet = new boolean[n];
   for (int i = 0; i < dist.length; i++) {
     dist[i] = Integer.MAX_VALUE;
     sptSet[i] = false;
   }
   dist[pos] = 0;
   for (int count = 0; count < n - 1; count++) {
     int u = minDistance(dist, sptSet);
     sptSet[u] = true;
     for (int v = 0; v < n; v++) {
       if (!sptSet[v] && mat[u][v] != 0 && dist[u] != Integer.MAX_VALUE && dist[u] + mat[u][v] < dist[v])
          dist[v] = dist[u] + mat[u][v];
     }
   }
 }

 private int[][] graphMatrix() {
   int n = vertexList.size();
   int[][] mat = new int[n][n];
   for (Road edge : edgeList) {
     int s = vertexList.indexOf(edge.getSource());
     int d = vertexList.indexOf(edge.getDestination());
     mat[s][d] = edge.getWeight();
   }
   return mat;
 }

 private int minDistance(int[] dist, boolean[] sptSet) {
   int min = Integer.MAX_VALUE;
   int min_index = -1;
   for (int i = 0; i < dist.length; i++) {
     if (sptSet[i] == false && dist[i] <= min) {
       min = dist[i];
       min_index = i;
     }
   }
   return min_index;
 }
}