/**
* This is the Road class
*
*
* @author Fatima Mancia
*
*/
public class Road implements Comparable<Road> {
  Town source;
  Town destination;
  int degrees;
  String name;
  public Road(Town source, Town destination, int degrees, String name) {
    this.name = name;
    this.source = source;
    this.destination = destination;
    this.degrees = degrees;
  }
  public Road(Town source, Town destination,String name) {
    this.name = name;
    this.source = source;
    this.destination = destination;
    this.degrees = 1;
  }
   /**
	 * contains contains the town name.
     @param town.
	 * @return true if the town equals source or destination.
	 *
	 */
  public boolean contains(Town town) {
    return town.equals(source) || town.equals(destination);
  }
   /**
	 * toString gets the Name of the source.
	 * @return the name of the source.
	 *
	 */
  public String toString() {
    return name + ": " + source.getName() + '-' + destination.getName();
  }
   /**
	 * getName gets the name.
	 * @return name.
	 *
	 */
  public String getName() {
    return name;
  }
   /**
	 * getDestination gets the destination.
	 * @return destination.
	 *
	 */
  public Town getDestination() {
    return destination;
  }
   /**
	 * getSource gets the source.
	 * @return source.
	 *
	 */
  public Town getSource() {
    return source;
  }
   /**
	 * compareTo compares the name of the Road.
     @param o.
	 * @return an int.
	 *
	 */
  public int compareTo(Road o) {
    return name.compareTo(o.name);
  }
   /**
	 * getWeight gets the degrees.
	 * @return degrees.
	 *
	 */
  public int getWeight() {
    return degrees;
  }
   /**
	 * equals equals the road name.
     @param r.
	 * @return true if the town equals source or destination.
	 *
	 */
  public boolean equals(Road r) {
    return name.equals(r.name) && source.equals(r.getSource()) && destination.equals(r.getDestination()) && (degrees == r.getWeight());
  }
}