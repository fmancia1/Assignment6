#!/bin/sh

CP="junit.jar:hamcrest-core.jar:."

# Compiling

javac DriverFX.java FXMainPane.java Graph_GFA_Test.java Graph.java GraphInterface.java GraphTest.java Road.java Town.java TownGraphManager_GFA_Test.java TownGraphManagerTest_STUDENT_Test.java TownGraphManager.java TownGraphManagerInterface.java TownGraphManagerTest.java GraphTest.java Road_STUDENT_Test.java .java 

# MorseCodeConverterTest.java
#MorseCodeConverter.java
 # IOException.java
# javac -cp $CP SortedDoubleLinkedListTest.java SortedDoubleLinkedList.java SortedDoubleLinkedList_GFA_Test.java 
# javac -cp $CP DoubleLinkedListDriver.java 

# Running
# java -cp $CP org.junit.runner.JUnitCore BasicDoubleLinkedListTest
# java -cp $CP org.junit.runner.JUnitCore SortedDoubleLinkedListTest
javac -cp junit-4.13.2.jar:hamcrest-core-1.3.jar:. Graph.java GraphInterface.java Graph_GFA_Test.java  GraphTest.java
java -cp junit-4.13.2.jar:hamcrest-core-1.3.jar:. org.junit.runner.JUnitCore  GraphTest
# timeout /t -1